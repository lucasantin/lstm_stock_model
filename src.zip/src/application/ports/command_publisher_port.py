class CommandPublisherPort:
  def __init__(self):
    pass

  def publish_historical_price(self, identifier: str, price: float, date_utc: str):
    pass